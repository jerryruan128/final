**To update a resource**

The following ``update-resource`` command updates the name of the specified resource. ::

    aws workmail update-resource \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --resource-id r-7afe0efbade843a58cdc10251fce992c \
        --name exampleRoom2

This command produces no output.
