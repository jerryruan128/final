**To get information about applications**

The following ``list-applications`` example displays information about all applications that are associated with the user's AWS account. ::

    aws deploy list-applications

Output::

    {
        "applications": [
            "WordPress_App",
            "MyOther_App"
        ]
    }
